# NEXWEAR – AI Fashion Store

An AI-themed e-commerce website for shoes and shirts.

## 🚀 Deploy to Vercel (Step-by-Step)

### Method 1: Drag & Drop (Easiest — No coding needed)

1. Go to **https://vercel.com** and sign up (free)
2. Click **"Add New Project"**
3. Click **"Deploy from folder"** or drag this folder onto the page
4. Click **Deploy**
5. Your site is LIVE! ✅ You'll get a URL like `https://nexwear.vercel.app`

---

### Method 2: GitHub + Vercel (Best for updates)

1. Create a free account at **https://github.com**
2. Create a new repository called `nexwear`
3. Upload `index.html` and `vercel.json` to the repo
4. Go to **https://vercel.com** → "Add New Project"
5. Click **"Import Git Repository"** → Select your GitHub repo
6. Click **Deploy** → Your site is live! ✅

Every time you update files on GitHub, Vercel auto-redeploys.

---

### Method 3: Vercel CLI

```bash
npm install -g vercel
cd your-folder
vercel
```

Follow the prompts — done!

---

## 📁 Files
- `index.html` — Full website (all-in-one)
- `vercel.json` — Vercel deployment config
- `README.md` — This file

## ✨ Features
- AI-animated background with floating particles
- 12 products: shoes, t-shirts, hoodies
- T-shirts priced from $28–$35 (varying prices)
- Add to cart with live count
- Cart sidebar with checkout
- Promo ad banner
- Fully mobile responsive
